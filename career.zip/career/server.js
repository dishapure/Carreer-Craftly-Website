require('dotenv').config();
const express = require('express');
const axios = require('axios');
const cors = require('cors');
const path = require('path');

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// 🧠 Enhanced OpenRouter AI Endpoint with CareerCraftly knowledge
app.post('/api/chat', async (req, res) => {
  try {
    const { message, context } = req.body;
    if (!message) return res.status(400).json({ error: "Message is required" });

    console.log(`💬 Chat request: "${message}"`);

    // Enhanced system prompt with CareerCraftly context
    const systemPrompt = `
      You are CareerCraftly AI, an expert career advisor for CareerCraftly. 
      Use this information to answer questions:
      
      ${context || 'No additional context provided'}
      
      Instructions:
      - Be concise (1-3 sentences)
      - Focus on career advice and course information
      - If asked about courses, provide duration, level, and key topics
      - If asked about services, explain benefits
      - For unknown questions, suggest contacting support
    `;

    const response = await axios.post(
      'https://openrouter.ai/api/v1/chat/completions',
      {
        model: "mistralai/mistral-7b-instruct",
        messages: [
          {
            role: "system",
            content: systemPrompt
          },
          {
            role: "user",
            content: message
          }
        ],
        max_tokens: 150 // Limit response length
      },
      {
        headers: {
          'Authorization': `Bearer ${process.env.OPENROUTER_API_KEY}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://careercraftly.org',
          'X-Title': 'CareerCraftly'
        }
      }
    );

    const aiResponse = response.data.choices[0].message.content;
    console.log(`🤖 AI Response: "${aiResponse}"`);
    res.json({ text: aiResponse });
  } catch (err) {
    console.error("🚨 OpenRouter API Error:", err.response?.data || err.message);
    
    // Course-specific fallback responses
    const fallbackResponses = [
      "I'm currently unavailable. For course info: Frontend Development (12 weeks) covers HTML/CSS/JS. Backend (14 weeks) covers server-side programming. Full Stack (24 weeks) combines both.",
      "CareerCraftly tip: Our AI & Machine Learning course (20 weeks) covers Python, ML algorithms, and model deployment. Perfect for data science careers!",
      "Contact us at anant@careercraftly.org or +91 8640058346 for personalized career advice."
    ];
    
    res.json({ 
      text: fallbackResponses[Math.floor(Math.random() * fallbackResponses.length)] 
    });
  }
});

// 📰 Fixed News API Endpoint
app.get('/api/news', async (req, res) => {
  try {
    console.log('\n📰 Fetching news from NewsAPI');
    const response = await axios.get(
      `https://newsapi.org/v2/top-headlines?category=technology&language=en&pageSize=5`,
      {
        headers: {
          'Authorization': `Bearer ${process.env.NEWS_API_KEY}`,
          'User-Agent': 'CareerCraftly/1.0'
        }
      }
    );

    if (response.data.status !== 'ok') {
      throw new Error(`NewsAPI error: ${response.data.message}`);
    }

    const validArticles = response.data.articles.filter(article =>
      article.title && article.description
    );

    console.log(`✅ Fetched ${validArticles.length} news articles`);
    res.json(validArticles.slice(0, 4));
  } catch (error) {
    console.error('🚨 News API Error:', error.message);
    
    // Fallback news data
    const fallbackNews = [
      {
        title: "Career Development Tips for 2025",
        description: "Learn how to future-proof your career in the rapidly evolving tech industry",
        url: "#",
        source: { name: "CareerCraftly Blog" },
        publishedAt: new Date().toISOString()
      },
      {
        title: "Tech Industry Growth Projections",
        description: "New report shows 15% year-over-year growth in tech hiring",
        url: "#",
        source: { name: "Tech Industry Report" },
        publishedAt: new Date().toISOString()
      }
    ];
    
    res.json(fallbackNews);
  }
});

// 🌐 Serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'final1.html'));
});

// 🚀 Start server
app.listen(port, () => {
  console.log(`\n🚀 Server running on http://localhost:${port}`);
  console.log('🔌 Endpoints:');
  console.log('- POST /api/chat (OpenRouter AI)');
  console.log('- GET  /api/news  (News API)');
});